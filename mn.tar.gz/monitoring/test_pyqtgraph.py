#!/usr/bin/python3
# encoding: utf-8

import pyqtgraph.examples
pyqtgraph.examples.run()
