#! /bin/bash
pyuic4 window.ui -o ui_window.py
