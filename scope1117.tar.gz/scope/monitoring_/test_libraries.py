import sklearn
print(sklearn.__version__)

import hmmlearn
print(hmmlearn.__version__)