# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'window.ui'
#
# Created: Sat Nov  5 15:21:07 2016
#      by: PyQt4 UI code generator 4.11.2
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName(_fromUtf8("MainWindow"))
        MainWindow.resize(987, 735)
        self.centralwidget = QtGui.QWidget(MainWindow)
        self.centralwidget.setMinimumSize(QtCore.QSize(935, 658))
        self.centralwidget.setObjectName(_fromUtf8("centralwidget"))
        self.verticalLayout_2 = QtGui.QVBoxLayout(self.centralwidget)
        self.verticalLayout_2.setObjectName(_fromUtf8("verticalLayout_2"))
        self.horizontalLayout_3 = QtGui.QHBoxLayout()
        self.horizontalLayout_3.setObjectName(_fromUtf8("horizontalLayout_3"))
        self.tabWidget = QtGui.QTabWidget(self.centralwidget)
        self.tabWidget.setObjectName(_fromUtf8("tabWidget"))
        self.tabGraph = QtGui.QWidget()
        self.tabGraph.setObjectName(_fromUtf8("tabGraph"))
        self.verticalLayout = QtGui.QVBoxLayout(self.tabGraph)
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        self.horizontalLayout = QtGui.QHBoxLayout()
        self.horizontalLayout.setObjectName(_fromUtf8("horizontalLayout"))
        self.verticalLayout_5 = QtGui.QVBoxLayout()
        self.verticalLayout_5.setObjectName(_fromUtf8("verticalLayout_5"))
        self.graphicsView_acc_x = PlotWidget(self.tabGraph)
        self.graphicsView_acc_x.setObjectName(_fromUtf8("graphicsView_acc_x"))
        self.verticalLayout_5.addWidget(self.graphicsView_acc_x)
        self.graphicsView_acc_y = PlotWidget(self.tabGraph)
        self.graphicsView_acc_y.setObjectName(_fromUtf8("graphicsView_acc_y"))
        self.verticalLayout_5.addWidget(self.graphicsView_acc_y)
        self.graphicsView_acc_z = PlotWidget(self.tabGraph)
        self.graphicsView_acc_z.setObjectName(_fromUtf8("graphicsView_acc_z"))
        self.verticalLayout_5.addWidget(self.graphicsView_acc_z)
        self.horizontalLayout.addLayout(self.verticalLayout_5)
        self.verticalLayout_4 = QtGui.QVBoxLayout()
        self.verticalLayout_4.setObjectName(_fromUtf8("verticalLayout_4"))
        self.graphicsView_ch1 = PlotWidget(self.tabGraph)
        self.graphicsView_ch1.setObjectName(_fromUtf8("graphicsView_ch1"))
        self.verticalLayout_4.addWidget(self.graphicsView_ch1)
        self.graphicsView_ch2 = PlotWidget(self.tabGraph)
        self.graphicsView_ch2.setObjectName(_fromUtf8("graphicsView_ch2"))
        self.verticalLayout_4.addWidget(self.graphicsView_ch2)
        self.graphicsView_ch3 = PlotWidget(self.tabGraph)
        self.graphicsView_ch3.setObjectName(_fromUtf8("graphicsView_ch3"))
        self.verticalLayout_4.addWidget(self.graphicsView_ch3)
        self.graphicsView_ch4 = PlotWidget(self.tabGraph)
        self.graphicsView_ch4.setObjectName(_fromUtf8("graphicsView_ch4"))
        self.verticalLayout_4.addWidget(self.graphicsView_ch4)
        self.graphicsView_ch5 = PlotWidget(self.tabGraph)
        self.graphicsView_ch5.setObjectName(_fromUtf8("graphicsView_ch5"))
        self.verticalLayout_4.addWidget(self.graphicsView_ch5)
        self.horizontalLayout.addLayout(self.verticalLayout_4)
        self.verticalLayout.addLayout(self.horizontalLayout)
        self.tabWidget.addTab(self.tabGraph, _fromUtf8(""))
        self.tabStatus = QtGui.QWidget()
        self.tabStatus.setObjectName(_fromUtf8("tabStatus"))
        self.tabWidget.addTab(self.tabStatus, _fromUtf8(""))
        self.horizontalLayout_3.addWidget(self.tabWidget)
        self.verticalLayout_2.addLayout(self.horizontalLayout_3)
        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QtGui.QMenuBar(MainWindow)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 987, 27))
        self.menubar.setObjectName(_fromUtf8("menubar"))
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QtGui.QStatusBar(MainWindow)
        self.statusbar.setObjectName(_fromUtf8("statusbar"))
        MainWindow.setStatusBar(self.statusbar)

        self.retranslateUi(MainWindow)
        self.tabWidget.setCurrentIndex(1)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        MainWindow.setWindowTitle(_translate("MainWindow", "ベッドモニタリングツール", None))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.tabGraph), _translate("MainWindow", "波形", None))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.tabStatus), _translate("MainWindow", "状態", None))

from pyqtgraph import PlotWidget
