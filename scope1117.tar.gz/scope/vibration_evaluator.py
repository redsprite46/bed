#!/usr/bin/python3
# encoding: utf-8

import numpy as np
import requests
import redis
import time


class VibrationEvaluator:

    def __init__(self):
        self.MAMORU_ID = 2001
        self.REDIS_SERVER = {'host': '192.168.60.3', 'port': 6379}
        self.POST_SERVER_URL = \
            'http://sansa.cs.shinshu-u.ac.jp/akita/MMRK/live.php'
        self.PIEZO_VIBRATION_THRESHOLD = 0.2
        self.ACC_VIBRATION_THRESHOLD = 0.3
        self.redis_ = redis.Redis(**(self.REDIS_SERVER))
        self.redis_.flushdb()
        self.last_post_time = {
            'BED': time.time() - 300,
            'PIL': time.time() - 300
            }

    def pop_piezo_data_in_redis(self):
        rawdata = self.redis_.lpop('judge_piezo')
        if rawdata is None:
            return None

        decoded = rawdata.decode('utf-8').split(':')
        data = np.zeros(5, dtype=np.float)
        for i in range(5):
            val = int(decoded[3 + i])
            data[i] = val / 1023.0 * 10 - 5.0
        return data

    def pop_acc_data_in_redis(self):
        rawdata = self.redis_.lpop('judge_acc')
        if rawdata is None:
            return None

        decoded = rawdata.decode('utf-8').split(':')
        data = np.zeros(3, dtype=np.float)
        for i in range(3):
            val = int(decoded[3 + i])
            data[i] = 6.0 * val / 1023.0 - 2.0
        return data

    def check_piezo_vibration(self):
        piezo_len = self.redis_.llen('judge_piezo')
        if piezo_len < 10:
            return None

        data_array = np.zeros((10, 5), dtype=np.float)
        for i in range(10):
            data = self.pop_piezo_data_in_redis()
            if data is None:
                return None
            data_array[i] = data

        differences = np.diff(data_array, axis=0)
        vibration = np.sum(np.absolute(differences), axis=0)
        print("piezo : {}".format(vibration))
        if max(vibration) > self.PIEZO_VIBRATION_THRESHOLD:
            return True
        else:
            return False

    def check_acc_vibration(self):
        piezo_len = self.redis_.llen('judge_acc')
        if piezo_len < 10:
            return None

        data_array = np.zeros((10, 3), dtype=np.float)
        for i in range(10):
            data = self.pop_acc_data_in_redis()
            if data is None:
                return None
            data_array[i] = data

        differences = np.diff(data_array, axis=0)
        vibration = np.sum(np.absolute(differences), axis=0)
        print("acc : {}".format(vibration))
        if max(vibration) > self.ACC_VIBRATION_THRESHOLD:
            return True
        else:
            return False

    def post(self, subject, color):
        payload = {'ID': self.MAMORU_ID, 'VER': '1', 'BOOT': '1'}
        payload[subject] = color
        r = requests.post(self.POST_SERVER_URL, params=payload)
        print("posted ({} : {}), {}".format(subject, color, r.text))
        self.last_post_time[subject] = time.time()

    def execute(self):
        while True:
            time.sleep(0.1)
            piezo_result = self.check_piezo_vibration()
            if piezo_result is True:
                self.post('BED', 'yellow')
            elif piezo_result is False:
                if abs(self.last_post_time['BED'] - time.time()) > 60:
                    self.post('BED', 'blue')

            acc_result = self.check_acc_vibration()
            if acc_result is True:
                self.post('PIL', 'yellow')
            elif acc_result is False:
                if abs(self.last_post_time['PIL'] - time.time()) > 60:
                    self.post('PIL', 'blue')


if __name__ == "__main__":
    evaluator = VibrationEvaluator()
    evaluator.execute()
