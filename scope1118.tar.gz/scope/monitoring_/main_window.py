#!/usr/bin/python3
# encoding: utf-8

from PyQt4 import QtCore
from PyQt4 import QtGui
from ui_window import Ui_MainWindow
import pyqtgraph as pg
import numpy as np
import redis


class MainWindow(QtGui.QMainWindow, Ui_MainWindow):
    def __init__(self, parent=None):
        super(MainWindow, self).__init__(parent)
        self.setupUi(self)

        self.x_ = np.arange(500)
        self.acc_ = np.zeros((3, 500))
        self.piezo_ = np.zeros((5, 500))
        self.redis_ = redis.Redis(host='localhost', port=6379)

        self.timer_ = pg.QtCore.QTimer()
        self.timer_.timeout.connect(self.update)
        self.timer_.start(50)

    def update(self):
        self.update_acc_wave()
        self.update_piezo_wave()

    def update_acc_wave(self):
        data_len = self.redis_.llen('monitordata0')
        if data_len > 0:
            # data_len is assured to be less than or equal to 500
            for i in range(3):
                self.acc_[i][0:500 - data_len] = self.acc_[i][data_len:500]

            for j in range(data_len):
                data = self.redis_.lpop('monitordata0')
                data = data.decode('utf-8').split(':')
                for i in range(3):
                    acc = int(data[3 + i])
                    self.acc_[i][500 - data_len + j] = acc

        self.graphicsView_acc_x.plot(
            self.x_, self.acc_[0], pen='y', clear=True)
        self.graphicsView_acc_y.plot(
            self.x_, self.acc_[1], pen='y', clear=True)
        self.graphicsView_acc_z.plot(
            self.x_, self.acc_[2], pen='y', clear=True)

    def update_piezo_wave(self):
        data_len = self.redis_.llen('monitordata1')
        if data_len > 0:
            # data_len is assured to be less than or equal to 500
            for i in range(5):
                self.piezo_[i][0:500 - data_len] = self.piezo_[i][data_len:500]

            for j in range(data_len):
                data = self.redis_.lpop('monitordata1')
                data = data.decode('utf-8').split(':')
                for i in range(5):
                    piezo = int(data[3 + i])
                    self.piezo_[i][500 - data_len + j] = piezo

        self.graphicsView_ch1.plot(
            self.x_, self.piezo_[0], pen='y', clear=True)
        self.graphicsView_ch2.plot(
            self.x_, self.piezo_[1], pen='y', clear=True)
        self.graphicsView_ch3.plot(
            self.x_, self.piezo_[2], pen='y', clear=True)
        self.graphicsView_ch4.plot(
            self.x_, self.piezo_[3], pen='y', clear=True)
        self.graphicsView_ch5.plot(
            self.x_, self.piezo_[4], pen='y', clear=True)


