#!/usr/bin/python3
# encoding: utf-8

import redis

rd = redis.Redis(host='localhost', port=6379)

while True:
    data_len = rd.llen('monitordata')
    if data_len > 0:
        for i in range(data_len):
            s = rd.lpop('monitordata')
            ss = s.decode('utf-8').split(':')
            print(ss[3])
