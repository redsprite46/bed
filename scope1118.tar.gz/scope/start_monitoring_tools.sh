#!/bin/bash
pushd ~/scope
perl readData.pl >/dev/null 2>&1 &
python3 vibration_evaluator.py >/dev/null 2>&1 & 
perl shake.pl >/dev/null 2>&1 & 
popd
